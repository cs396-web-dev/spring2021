console.log("Hello, World!");
listPrint(["line1", "line2", "line3"]);
fibonacci(12);

/* Edit the below functions: */

function listPrint(arr) {

}

function fibonacci(n) {

}
