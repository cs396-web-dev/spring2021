const names = [
    "Jane", "Brenda", "Wanda", "Maria", "Jasper",
    "John", "Malik", "Arjun", "Larry", "Curly", "Moe"
];

/* Use the built-in forEach array method and a template string 
literal to output a greeting to all of the people in the 
"names" array.
*/

// replace this code: 
const name = names[0];
document.write(`<p>Welcome ${name}</p>`);

