utils = require("./utilities");

const { populateDB } = utils;

populateDB();
